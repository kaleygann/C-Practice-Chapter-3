/* 3.21
 * This program will demonstrate the difference
 * between predecrementing and postdecrementing
 * using decrement operator --
 */

#include <stdio.h>

int main() { //main header

    //initialize variables
    int a = 10;
    int b = 10;

    printf("a value: %d\n", --a);
    printf("b value: %d", b--);

} //end main
